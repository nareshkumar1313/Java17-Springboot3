package com.java17.springboot3.springboot3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java17springboot3Application {

	public static void main(String[] args) {
		SpringApplication.run(Java17springboot3Application.class, args);
	}

}
