package com.java17.springboot3.springboot3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java17springboot3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
